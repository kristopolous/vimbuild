<?php

$find_me = "var";
$find_me2 = time();
$find_me3 = new DateTime;
$find_me4 = new BarClass;
$dont_find_me = 42;
