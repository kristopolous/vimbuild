<?php
try {
    foo();
} catch (Exception $e) {
    $e->
}

try {
    foo();
} catch (NS\Exception $e) {
    $e->
}
