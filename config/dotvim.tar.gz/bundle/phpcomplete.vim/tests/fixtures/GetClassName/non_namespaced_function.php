<?php

/**
 * no_ns_make_a_foo
 *
 * @return Foo\FooClass
 */
function no_ns_make_a_foo() {
}
