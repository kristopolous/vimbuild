<?php
interface FooInterface {
    const SOME_CONTENT = 'bar';
}
