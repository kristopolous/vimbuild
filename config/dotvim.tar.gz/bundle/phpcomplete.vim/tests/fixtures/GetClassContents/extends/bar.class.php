<?php

class BarClass { }
