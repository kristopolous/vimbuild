<?php

class Foo3 {
	use FooTrait;

	public function bar() {
	}
}
